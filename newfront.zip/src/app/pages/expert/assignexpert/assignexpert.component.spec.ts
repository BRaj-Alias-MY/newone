import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignexpertComponent } from './assignexpert.component';

describe('AssignexpertComponent', () => {
  let component: AssignexpertComponent;
  let fixture: ComponentFixture<AssignexpertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignexpertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignexpertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
