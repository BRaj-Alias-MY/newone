import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  dasboardData: any;
  totalusers: any;

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
          ticks: {
              beginAtZero:true
          },
          scaleLabel: {
            display: true,
            labelString: 'Payments in USD'
          }
      }]
    }
  };
  public barChartLabels : any;
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData :any;

  public doughnutChartLabels :any;
  public doughnutChartData :any;

  public doughnutChartType = 'doughnut';

  private donutColors=[
    {
    backgroundColor: [
    '#ff8080',
    '#ffcc80',
    '#99ffff',
    'rgba(129, 78, 40, 1)',
    'rgba(129, 199, 111, 1)'
    ]
    }
    ];
  
  constructor(private api: ApiService) {
    this.barChartLabels = [];
    this.barChartData = [
      {data: [], label: 'Monthwise Payments'}
    ];
    this.doughnutChartLabels = [];
    this.doughnutChartData = [];
   }
  ngOnInit() {
    this.api.admindashboard().subscribe(data=>{
      this.dasboardData = data.data;
      let expertusers = this.dasboardData.usersdata.Expert ? this.dasboardData.usersdata.Expert : 0;
      let orgusers = this.dasboardData.usersdata.Organization ? this.dasboardData.usersdata.Organization : 0;
      let endusers = this.dasboardData.usersdata.User ? this.dasboardData.usersdata.User : 0;
      this.totalusers = expertusers+orgusers+endusers;
      for(let i=0;i< this.dasboardData.thismonth.length;i++){
        this.doughnutChartLabels.push(this.dasboardData.thismonth[i].mode);
        this.doughnutChartData.push(Number(this.dasboardData.thismonth[i].total));
      }
      for(let i=0;i< this.dasboardData.monthlydata.length;i++){
        this.barChartLabels.push(this.dasboardData.monthlydata[i].month);
        this.barChartData[0].data.push(Number(this.dasboardData.monthlydata[i].total));
      }
      console.log(this.barChartData);
    });
  }

}
