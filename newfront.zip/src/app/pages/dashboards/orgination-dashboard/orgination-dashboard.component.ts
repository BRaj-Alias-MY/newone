import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-orgination-dashboard',
  templateUrl: './orgination-dashboard.component.html',
  styleUrls: ['./orgination-dashboard.component.css']
})
export class OrginationDashboardComponent implements OnInit {
  dasboardData:any;
  plan : any;

  constructor(private api: ApiService) { }

  ngOnInit() {
    this.dasboardData = {monthlydata: [], plan: [],sumary: {}};
    this.api.organizationdashboard().subscribe(data=>{
      this.dasboardData = data.data;
      this.plan = this.dasboardData.plan;
  });

}
}