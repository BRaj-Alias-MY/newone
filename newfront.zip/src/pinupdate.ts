export class Pin {

    pin: number;
    email: string;
    status: string;
    timetaken: string;
}