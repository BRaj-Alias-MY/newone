/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_user_questions = sequelize.define('interview_user_questions', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    type: {
      type: DataTypes.ENUM('fixed','random'),
      allowNull: false
    },
    interviewUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_users',
        key: 'id'
      }
    },
    questionId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'questions',
        key: 'id'
      }
    },
    answerLink: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    answerText: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    questionTitle: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    ano: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    uid: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    qTime: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    status: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    maxCount: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    timeTaken:{
      type: DataTypes.TEXT,
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_user_questions'
  });
  interview_user_questions.associate = function(models) {
	  interview_user_questions.belongsTo(models.interview_users, {foreignKey: 'interviewUserId', targetKey: 'id'});
  };

  return interview_user_questions;
};
