let app = require('express');
let router = app.Router();
let exp_level = require('../models').exp_level;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;



router.get('/list',(req,res)=>{
      if(req.auth.organization){
		exp_level.findAll({ attributes:["id","experiance"],where : {[Op.or]: [{organizationId: req.auth.organization}, {organizationId: null}]}}).then(experiance => {
			if(experiance){
				res.send({'status' : true, "data" : experiance});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }else{
            exp_level.findAll({attributes:["id","experiance"]}).then(experiance => {
			if(experiance){
				res.send({'status' : true, "data" : experiance});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }
            
});

router.get('/',(req,res)=>{
      if(req.auth.access.gridAccess && !req.auth.organization){
		exp_level.findAll({ where : {organizationId:req.auth.organization}}).then(experiance => {
			if(experiance){
				res.send({'status' : true, "data" : experiance, access:req.auth.access});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }else if(req.auth.access.gridAccess){
            exp_level.findAll().then(experiance => {
			if(experiance){
				res.send({'status' : true, "data" : experiance, access:req.auth.access});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }else{
            res.send({'status' : false, 'message':'Un Authroized', access:[req.auth.access]});
      }
            
});

router.post('/',(req,res)=>{
      if(req.auth.access.addAccess && req.auth.organization){
		exp_level.findOne({ where : {organizationId:req.auth.organization,experiance:req.body.experiance}}).then(experiance => {
			if(experiance){
				res.send({'status' : false, "message":"Data Already Exist."});
			}else{
				//============= insert query =====================
				exp_level.afterCreate(function(model, options, done) {//hook1
					model.auth = req.auth ? req.auth.userId : 0;
				});
				exp_level.create({experiance:req.body.experiance,organizationId:req.auth.organization,userId:req.auth.userId}).then(result=>{
					res.send({'status' : true, 'message':'Success'});
				}).catch(err=>{
					res.send({"status":false,"message":"fail"});
				});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }else if(req.auth.access.addAccess){
            exp_level.findOne({ where : {experiance:req.body.experiance}}).then(experiance => {
			if(experiance){
				res.send({'status' : false, "message":"Data Already Exist."});
			}else{
				//================== insert query =============
				exp_level.afterCreate(function(model, options, done) {//hook1
					model.auth = req.auth ? req.auth.userId : 0;
				});
				exp_level.create({experiance:req.body.experiance,organizationId:req.auth.organization,userId:req.auth.userId}).then(result=>{
					res.send({'status' : true, 'message':'Success'});
				}).catch(err=>{
					res.send({"status":false,"message":"fail"});
				});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
            });
      }else{
            res.send({'status' : false, 'message':'Un Authroized'});
      }
            
});

router.get('/:id',(req,res)=>{
	exp_level.findOne({ where: {id : req.params.id}}).then(exp => {
        if(exp){
            res.send({'status' : true, "message" : exp});
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
	}).catch(err=>{
		res.send({status:false,'message':'Fail'});
	});
});

router.post('/:id',(req,res)=>{
	exp_level.afterBulkUpdate(function(options) {//hook1
		options.auth = req.auth ? req.auth.userId : 0;
	});
	exp_level.update({experiance:req.body.experiance},{ where: { id: req.params.id }}).then(result=>{
		res.send({'status' : true, "message" : "success"});
	}).catch(err=>{
		console.log(err);
		res.send({'status' : false, 'message':'fail'});
	});
});

module.exports = router;

