let app = require('express');
let router = app.Router();
let interview_types = require('../models').interview_types;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;


router.get('/list',(req,res)=>{
    interview_types.findAll({attributes:['id','name','price'],where:[{status:'active'}]}).then(experiance => {
        if(experiance){
            res.send({'status' : true, "data" : experiance});
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
    }).catch(function (error) {
        res.status(500).send('Internal Server Error');
    });
});

router.get('/',(req,res)=>{
    if(req.auth.access.gridAccess){
        interview_types.findAll().then(experiance => {
          if(experiance){
              res.send({'status' : true, "data" : experiance, access:req.auth.access});
          }else{
              res.send({'status' : false, 'message':'fail'});
          }
      }).catch(function (error) {
          res.status(500).send('Internal Server Error');
          });
    }else{
          res.send({'status' : false, 'message':'Un Authroized', access:[req.auth.access]});
    }
          
});

router.post('/',(req,res)=>{
    if(req.auth.access.addAccess){
        interview_types.findOne({ where : {name:req.body.name}}).then(experiance => {
          if(experiance){
              res.send({'status' : false, "message":"Data Already Exist."});
          }else{
              //============= insert query =====================
              interview_types.afterCreate(function(model, options, done) {//hook1
                  model.auth = req.auth ? req.auth.userId : 0;
              });
              interview_types.create({name:req.body.name,price:req.body.price,status:'active'}).then(result=>{
                  res.send({'status' : true, 'message':'Success'});
              }).catch(err=>{
                  res.send({"status":false,"message":"fail111"});
              });
          }
      }).catch(function (error) {
          res.status(500).send('Internal Server Error');
          });
    }else{
          res.send({'status' : false, 'message':'Un Authroized'});
    }
          
});

module.exports = router;
