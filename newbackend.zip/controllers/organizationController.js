let app = require('express');
let router = app.Router();
let organization = require('../models').organization;
let organization_campus = require('../models').organization_campus;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;

router.get('/list',(req,res)=>{
	if(req.auth.access.addAccess || req.auth.access.editAccess || req.auth.access.gridAccess || req.auth.access.viewAccess){
		let apd = req.auth.access.addAccess? '' : ' and organization_campus.id='+req.auth.organizationId;
		let qry = "SELECT concat(organization_campus.branchName,'(',organization.name,')') as name,organization_campus.id FROM `organization_campus` left join organization on organization_campus.organizationId = organization.id where organization_campus.status='active' and organization.name<>'' "+apd;
		sequelize.query(qry, { type: sequelize.QueryTypes.SELECT})
		.then(dataa => {
			res.send({status:true,data:dataa});
		}).catch(err=>{
			res.send({status:fail,data:[]});
		})
	}else{
		res.send({status:fail,data:[]});
	}
});
//=============== get all data ============================
router.get('/',(req,res)=>{
	if(req.auth.access.gridAccess){
		organization.findAll({ include: [{model:organization_campus,where:{status:'active'},duplicating: false} ] }).then(org => {
			if(org){
				res.send({'status' : true, "data" : org, access:req.auth.access});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
		});

	}else{
		res.send({'status' : false, 'message':'Un Autherized.', access:[req.auth.access]});
	}
});


router.get('/:page',(req,res)=>{
	let limit = 10;
	let offset = 0;
	if(req.auth.role==1){
		organization.findAndCountAll().then((data) => {
			let page = req.params.page;      // page number
			let pages = Math.ceil(data.count / limit);
			offset =  limit * (page - 1);
			organization.findAll({ limit: limit,offset: offset,duplicating: false,required: true}).then(async org => {
				if(org){
					let dep = {};
					dep.current_page = Number(page);
					dep.total_pages = pages;
					dep.total_records = data.count;
					dep.limit = limit;
					//================================
					// for(let p=0;p<org.length;p++){
					// 	dep.data[p] = org[p];
					// 	await organization_campus.findAll({where:[{status:'active',organizationId:org[p].id}]}).then(org_camp=>{
					// 		dep.data[p].organization_campuses = org_camp;
					// 	})
					// }
					dep.data = org;
					//=================================
					res.send({'status' : true, "data" : dep});
				}else{
					res.send({'status' : false, 'message':'fail'});
				}
			})
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
		});

	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});
//=================== Insert data =============================
router.post('/',(req,res)=>{
	if(req.auth.access.addAccess){
		return organization.findOne({ where: {name : req.body.name} }).then(org => {
			if(org){
				res.send({'status' : false, "message" : 'Organization already exists.'});
			}else{
				let user_data = req.body;
				
				return sequelize.transaction().then(function (t) {
					organization.afterCreate(function(model, options, done) {//hook1
						model.auth = req.auth ? req.auth.userId : 0;
					});
					return organization.create({
						name:user_data.name,
						type:user_data.type,
						url:user_data.url,
						email:user_data.email
					}, {transaction: t}).then(async (orgnize)=>{
						for(let i=0;i<user_data.organization.length;i++){
							await organization_campus.afterCreate(function(model, options, done) {//hook1
								model.auth = req.auth ? req.auth.userId : 0;
							});
							await organization_campus.create({
								branchName:user_data.organization[i].branchName,
								organizationId:orgnize.id,
								address:user_data.organization[i].address,
								city:user_data.organization[i].city,
								pincode:user_data.organization[i].pincode,
								url:user_data.organization[i].url,
								contactPerson:user_data.organization[i].contactPerson,
								contactPersonEmail:user_data.organization[i].contactPersonEmail,
								contactPersonPhone:user_data.organization[i].contactPersonPhone,
								contactPersonDesgination:user_data.organization[i].contactPersonDesgination,
								status:'active'
							}, {transaction: t});
						}
						return true;
					}).then(function (result) {
						return t.commit();
					}).catch(function (err) {
						console.log(err);
						//res.send({'status' : false, "message" : 'Fail'});
						return t.rollback();
					});
				}).then(function (result) {
				  res.send({'status' : true, "message" : 'success'});
				}).catch(function (err) {
				  res.send({'status' : false, "message" : 'Fail'});
				});
			}
		})
	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});
//============================ view by single id ==========================
router.get('/view/:id',(req,res)=>{
	if(req.auth.access.viewAccess){
		organization.findOne({ where: {id : req.params.id},include: [{model:organization_campus,where:{status:'active'}} ] }).then(org => {
        if(org){
            res.send({'status' : true, "data" : org});
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
		})
	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});
//============================ update using row id ==========================
router.post('/update',(req,res)=>{
	if(req.auth.access.editAccess && req.body.id>0){
		let user_data = req.body;
		return sequelize.transaction().then(function (t) {
			organization.afterBulkUpdate(function(options) {//hook1
				options.auth = req.auth ? req.auth.userId : 0;
			});
			return organization.update({
				name:user_data.name,
				type:user_data.type,
				url:user_data.url,
				email:user_data.email
			},{ where: { id: user_data.id }}, {transaction: t}).then((orgnize)=>{
				organization_campus.afterBulkUpdate(function( options) {//hook1
					options.auth = req.auth ? req.auth.userId : 0;
				});
				return organization_campus.update({
					status:'inactive'
				},{ where: { organizationId: user_data.id}}, {transaction: t}).then(async (result_of_up)=>{
					for(let i=0;i<user_data.organization.length;i++){
						if(user_data.organization[i].id>0){
							organization_campus.afterBulkUpdate(function(options) {//hook1
								options.auth = req.auth ? req.auth.userId : 0;
							});
							await organization_campus.update({
								branchName:user_data.organization[i].branchName,
								address:user_data.organization[i].address,
								city:user_data.organization[i].city,
								pincode:user_data.organization[i].pincode,
								url:user_data.organization[i].url,
								contactPerson:user_data.organization[i].contactPerson,
								contactPersonEmail:user_data.organization[i].contactPersonEmail,
								contactPersonPhone:user_data.organization[i].contactPersonPhone,
								contactPersonDesgination:user_data.organization[i].contactPersonDesgination,
								status:'active'
							},{where: { id: user_data.organization[i].id }}, {transaction: t});
						}else{
							organization_campus.afterCreate(function(model, options, done) {//hook1
								model.auth = req.auth ? req.auth.userId : 0;
							});
							await organization_campus.create({
								branchName:user_data.organization[i].branchName,
								organizationId:user_data.id,
								address:user_data.organization[i].address,
								city:user_data.organization[i].city,
								pincode:user_data.organization[i].pincode,
								url:user_data.organization[i].url,
								contactPerson:user_data.organization[i].contactPerson,
								contactPersonEmail:user_data.organization[i].contactPersonEmail,
								contactPersonPhone:user_data.organization[i].contactPersonPhone,
								contactPersonDesgination:user_data.organization[i].contactPersonDesgination,
								status:'active'
							}, {transaction: t});
						}
					}
					return true;
				});
			}).then(function (result) {
				return t.commit();
			}).catch(function (err) {
				console.log(err);
				//res.send({'status' : false, "message" : 'Fail'});
				return t.rollback();
			});
		}).then(function (result) {
		  res.send({'status' : true, "message" : 'success'});
		}).catch(function (err) {
		  res.send({'status' : false, "message" : 'Fail'});
		});
			
	}else{		
		req.body.id>0 ? res.send({'status' : false, 'message':'Un Autherized.'}) : res.send({'status' : false, 'message':'Invalid requiest.'});
	}
});


module.exports = router;