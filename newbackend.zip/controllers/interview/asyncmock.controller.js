const AsyncMocks = require ('../../models').AsyncMocks;

exports.asyncmock = (req, res) => {
  AsyncMocks.sequelize
    .query (
      'insert into myexams(InterviewId,q_title,ano,uid,answer,userId,status,max_count,time_taken,createdAt,updatedAt) select InterviewId,q_title,ano,uid,answer,userId,status,max_count,time_taken,createdAt,updatedAt from asyncmocks where InterviewId=' +
        req.params.InterviewId
    )
    .spread ((results, metadata) => {
      //res.send (results.body);
    });
};
