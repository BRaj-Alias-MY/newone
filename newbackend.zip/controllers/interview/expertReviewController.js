let app = require('express');
let router = app.Router();
let interview_experts = require('../../models').interview_experts;
let interview_experts_feedback = require('../../models').interview_experts_feedback;
let interview_expert_overall_feedback = require('../../models').interview_expert_overall_feedback;
let interview_users = require('../../models').interview_users;
let report_perameters = require('../../models').report_perameters;
let interview_user_questions = require('../../models').interview_user_questions;
let sequelize = require('../../models').sequelize;
const Op = sequelize.Op;

router.get('/assign-interviews-list',(req,res)=>{
	sequelize.query("SELECT interview_users.id,interview_users.email,interview.interviewId,domain.domainName,sub_domains.subDomainName,concat(organization.name,'(',organization_campus.branchName,')') as organization,exp_level.experiance FROM `interview_users` left join interview on interview_users.interviewId = interview.id left join domain on interview.domainId = domain.id left join sub_domains on interview.subDomainId = sub_domains.id left join organization_campus on interview.organizationId = organization_campus.id left join organization on organization_campus.organizationId = organization.id left join exp_level on interview.expLevelId = exp_level.id where interview_users.status='Completed'", { type: sequelize.QueryTypes.SELECT}).then(data=>{
		if(data){
			res.send({status:true,'data':data})
		}else{
			res.send({status:false,'message':'no data found'})
		}
	}).catch(err=>{
		res.send({status:false,'message':'fail'})
	})
});

router.post('/assign-interview',(req,res)=>{
	let userdata = req.body;
	interview_user_questions.findAll({where:{interviewUserId:userdata.interviewUserId},order:[["ano","ASC"]]}).then(quesData=>{
		sequelize.transaction(t=>{
			interview_experts.afterCreate(function(model, options, done) {//hook1
				model.auth = req.auth ? req.auth.userId : 0;
			});
			return interview_experts.create({interviewUserId:userdata.interviewUserId,expertId:userdata.expertId,status:'open'},{transaction:t}).then(expId=>{
				let quesDataSet = quesData.map((v,i)=>{
					return {interviewExpertId:expId.id,interviewUserQuestionId:v.id};
					interview_experts_feedback.afterBulkCreate(function(model,options) {
						options.auth = req.auth ? req.auth.userId : 0;
					});
				});
				return interview_experts_feedback.bulkCreate(quesDataSet,{transaction:t});
			})
		}).then(result=>{
			interview_users.afterBulkUpdate(function(options) {//hook1
				options.auth = req.auth ? req.auth.userId : 0;
		  });
			interview_users.update({status:"expertreview"},{where:{id:userdata.interviewUserId}});
			res.send({status:true,message:"success"});
		}).catch(err=>{
			console.log(err)
			res.send({status:false,message:"fail"});
		})
	}).catch(err=>{
		res.send({status:false,message:"fail"});
	})
});

router.get('/interview-list-expert',(req,res)=>{
	let qry = "SELECT interview_experts.id,interview_users.email,interview.interviewId,domain.domainName,sub_domains.subDomainName FROM `interview_experts` left join interview_users on interview_experts.interviewUserId = interview_users.id left join interview on interview_users.interviewId = interview.id left join domain on interview.domainId = domain.id left join sub_domains on interview.subDomainId = sub_domains.id where interview_experts.expertId="+req.auth.userId+" and interview_experts.status='open'";
	sequelize.query(qry, { type: sequelize.QueryTypes.SELECT}).then(data=>{
		if(data){
			res.send({status:true,'data':data})
		}else{
			res.send({status:false,'message':'no data found'})
		}
	}).catch(err=>{
		res.send({status:false,'message':'fail'})
	})
});

router.get('/interview-list-expert/:id',(req,res)=>{
	interview_experts.findOne({include:[{model:interview_experts_feedback,include:["interview_user_question"]},{model:interview_users,include:["interview"]}],where:{expertId:req.auth.userId,id:req.params.id}}).then(data=>{
		orgid = data.interview_user.interview.organizationId;
		report_perameters.findAll({attributes:['id','name'],where:{organizationId:orgid,status:'active'}}).then(repData=>{
			res.send({status:true,data:data,reportparms:repData});
		}).catch(err=>{
			res.send({status:false,message:'fail'})
		})
	}).catch(err=>{
		res.send({status:false,message:'fail'})
	})
});

router.post('/save-review-question/:id',(req,res)=>{
	interview_experts_feedback.afterBulkUpdate(function(options) {//hook1
		options.auth = req.auth ? req.auth.userId : 0;
  });
	interview_experts_feedback.update({review:req.body.review,rating:req.body.rating},{where:{id:req.params.id}}).then(data=>{
		res.send({status:true,message:"sucess"})
	}).catch(err=>{
		res.send({status:false,message:"fail"})
	})
});

router.post('/review-submit/:id',(req,res)=>{
	console.log(req.body)
	let userdata = req.body.reportFeedback.map((v,i)=>{
		return {reportPerameterId:v.reportPerameterId,interviewExpertId:req.params.id,review:v.review,rating:v.rating}
	});
	interview_experts.findOne({where:{id:req.params.id}}).then(intExpData=>{
		return sequelize.transaction(t=>{
			interview_expert_overall_feedback.afterBulkCreate(function(model,options) {
				options.auth = req.auth ? req.auth.userId : 0;
			});
			return interview_expert_overall_feedback.bulkCreate(userdata,{transcation:t}).then(sus=>{
				interview_experts.afterBulkUpdate(function(options) {//hook1
					options.auth = req.auth ? req.auth.userId : 0;
			  });
				return interview_experts.update({status:'completed',feedback:req.body.feedback},{where:{id:req.params.id}},{transcation:t}).then(sus1=>{
					interview_users.afterBulkUpdate(function(options) {//hook1
						options.auth = req.auth ? req.auth.userId : 0;
				  });
					return interview_users.update({status:'Reviewed'},{where:{id:intExpData.interviewUserId}})
				})
			})
		}).then(result=>{
			res.send({status:true,message:"success"})
		}).catch(err=>{
			console.log(err);
			res.send({status:false,message:"fail"})
		})
	}).catch(err=>{
		res.send({status:false,message:"fail"})
	})
});


router.get('/getInterviewById/:id',(req,res)=>{
	let qry = "SELECT * from  interview_user_questions where id="+req.params.id;
	sequelize.query(qry, { type: sequelize.QueryTypes.SELECT}).then(data=>{
		if(data){
			res.send({data})
		}else{
			res.send({status:false,'message':'no data found'})
		}
	}).catch(err=>{
		res.send({status:false,'message':'fail'})
	})
});

router.get('/user-review/:id',(req,res)=>{
	interview_experts.findAll({include:[{model:interview_experts_feedback,include:["interview_user_question"]},{model:interview_users,include:["interview"]}],where:{interviewUserId:req.params.id,status:'completed'}}).then(data=>{
		if(data.length>0)
			res.send({status:true,data:data});
		else
			res.send({status:false,message:'No data found.'})
	}).catch(err=>{
		res.send({status:false,message:'fail'})
	})
});

module.exports = router;