//const crypto = require('crypto').randomBytes(256).toString('hex'); 
const crypto = 'AE8099448500641'; 
const mailkey = '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';
// Export config object
module.exports = {
  secret: crypto,
  mailkey: mailkey
}